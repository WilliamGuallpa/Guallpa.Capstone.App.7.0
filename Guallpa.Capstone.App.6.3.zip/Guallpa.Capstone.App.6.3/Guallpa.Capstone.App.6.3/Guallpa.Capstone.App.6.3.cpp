// Guallpa.Capstone.App.6.3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

class Queue {
private:
    static const int MAX_SIZE = 100; // Maximum size of the queue
    int elements[MAX_SIZE]; // Array to store elements
    int frontIndex; // Index of the front element
    int rearIndex; // Index of the rear element

public:
    // Constructor to initialize an empty queue
    Queue() : frontIndex(-1), rearIndex(-1) {}

    // Method to check if the queue is empty
    bool isEmpty() const {
        return frontIndex == -1;
    }

    // Method to check if the queue is full
    bool isFull() const {
        return (rearIndex + 1) % MAX_SIZE == frontIndex;
    }

    // Method to add an element to the rear of the queue
    void enqueue(int item) {
        // Check if the queue is full
        if (isFull()) {
            throw std::runtime_error("Queue is full");
        }
        // If the queue is empty, update both frontIndex and rearIndex
        if (isEmpty()) {
            frontIndex = 0;
            rearIndex = 0;
        }
        else { // Otherwise, update rearIndex
            rearIndex = (rearIndex + 1) % MAX_SIZE;
        }
        // Add the new element to the rear of the queue
        elements[rearIndex] = item;
    }

    // Method to remove and return the front element of the queue
    int dequeue() {
        // Check if the queue is empty
        if (isEmpty()) {
            throw std::runtime_error("Queue is empty");
        }
        // Get the data from the frontIndex
        int data = elements[frontIndex];
        // If there is only one element in the queue, reset frontIndex and rearIndex
        if (frontIndex == rearIndex) {
            frontIndex = -1;
            rearIndex = -1;
        }
        else { // Otherwise, move frontIndex to the next element
            frontIndex = (frontIndex + 1) % MAX_SIZE;
        }
        // Return the data removed from the queue
        return data;
    }

    // Method to return the front element of the queue without removing it
    int peek() const {
        // Check if the queue is empty
        if (isEmpty()) {
            throw std::runtime_error("Empty Queue");
        }
        // Return the data from the frontIndex
        return elements[frontIndex];
    }
};

void interactWithQueue(Queue& myQueue) {
    int choice, item;

    do {
        std::cout << "\nMenu:\n";
        std::cout << "1. Enqueue\n";
        std::cout << "2. Dequeue\n";
        std::cout << "3. Peek\n";
        std::cout << "4. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Enter the item to enqueue: ";
            std::cin >> item;
            try {
                myQueue.enqueue(item);
                std::cout << "Item enqueued.\n";
            }
            catch (const std::runtime_error& e) {
                std::cerr << "Error: " << e.what() << std::endl;
            }
            break;
        case 2:
            try {
                std::cout << "Dequeued item: " << myQueue.dequeue() << std::endl;
            }
            catch (const std::runtime_error& e) {
                std::cerr << "Error: " << e.what() << std::endl;
            }
            break;
        case 3:
            try {
                std::cout << "Front element: " << myQueue.peek() << std::endl;
            }
            catch (const std::runtime_error& e) {
                std::cerr << "Error: " << e.what() << std::endl;
            }
            break;
        case 4:
            std::cout << "Exit program.\n";
            break;
        default:
            std::cerr << "Not a valid choice! Please enter a valid option.\n";
        }
    } while (choice != 4);
}

int main() {
    Queue useQueue; // Create a queue object
    interactWithQueue(useQueue);
    return 0;
}

